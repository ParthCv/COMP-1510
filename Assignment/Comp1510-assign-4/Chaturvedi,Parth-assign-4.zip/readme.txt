[Parth Chaturvedi], [A01256537], [B], [15-04-2021]

This assignment is [66]% complete.


------------------------
Question one (Timesheet) status:

not complete
------------------------
Question two (Exponential) status:

complete 

------------------------
Question three (TestMIXChar) status:

complete
