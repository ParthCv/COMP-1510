module ca.bcit.comp1510.atwo {
    exports q1;
    exports q2;
    exports q3;
    exports q4;
    exports q5;
}