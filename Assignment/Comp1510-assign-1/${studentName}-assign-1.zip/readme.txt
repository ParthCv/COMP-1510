[Parth Chaturvedi], [A01256537], [B], [31-01-2021]

This assignment is 100% complete.


------------------------
Question one (Change) status:

complete
------------------------
Question two (SecondsConvert) status:

complete 
------------------------
Question three (Arithmetic) status:

complete 
------------------------
Question four (Sqrt) status:

complete
------------------------
Question five (Pack) status:

complete