module ca.bcit.comp1510.a4 {
    requires org.junit.jupiter.api;

    exports q1;
    exports q2;
    exports q3;
}