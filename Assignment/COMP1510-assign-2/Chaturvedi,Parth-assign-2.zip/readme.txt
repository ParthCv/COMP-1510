[Chaturvedi,Parth], [A01256537], [B], [12-02-2021]

This assignment is 100% complete.


------------------------
Question one (PhoneNumbers) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (Balloon) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (Cylinder) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Box) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question five (DiscountCalculator) status: complete

[complete or not complete]
[explanation if not complete, what is working/not working]
